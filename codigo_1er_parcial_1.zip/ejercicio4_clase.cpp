#include <iostream>
#include <string>
using namespace std;

class Estudiante {
public:
    string nombre;
    string matricula;
    float promedio;

    Estudiante(string n, string m, float p) {
        nombre = n;
        matricula = m;
        promedio = p;
    }

    void mostrarInfo() {
        cout << "Nombre: " << nombre << endl;
        cout << "Matricula: " << matricula << endl;
        cout << "Promedio: " << promedio << endl;
    }

    bool enRiesgo() {
        return promedio < 70;
    }
};

int main() {
    Estudiante e1("Jose Augusto", "5262018", 88.5);
    Estudiante e2("Carlos", "5260001", 64);

    e1.mostrarInfo();
    if (e1.enRiesgo()) {
        cout << "Esta en riesgo academico" << endl;
    } else {
        cout << "No esta en riesgo academico" << endl;
    }

    cout << endl;

    e2.mostrarInfo();
    if (e2.enRiesgo()) {
        cout << "Esta en riesgo academico" << endl;
    } else {
        cout << "No esta en riesgo academico" << endl;
    }

    return 0;
}
