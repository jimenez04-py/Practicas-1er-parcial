#include <iostream>
using namespace std;

int main() {
    int calificacion;

    cout << "Calificacion (0-100): ";
    cin >> calificacion;

    if (calificacion < 0 || calificacion > 100) {
        cout << "La calificacion debe estar entre 0 y 100" << endl;
    } else if (calificacion < 70) {
        cout << "Nivel: NA (No acreditado)" << endl;
    } else if (calificacion < 80) {
        cout << "Nivel: S (Suficiente)" << endl;
    } else if (calificacion < 90) {
        cout << "Nivel: B (Bueno)" << endl;
    } else if (calificacion < 100) {
        cout << "Nivel: MB (Muy bueno)" << endl;
    } else {
        cout << "Nivel: E (Excelente)" << endl;
    }

    return 0;
}
