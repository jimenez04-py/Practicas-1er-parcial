#include <iostream>
using namespace std;

int main() {
    double a, b;
    char op;

    cout << "Primer numero: ";
    cin >> a;
    cout << "Operador (+, -, *, /): ";
    cin >> op;
    cout << "Segundo numero: ";
    cin >> b;

    switch (op) {
        case '+':
            cout << "Resultado: " << a + b << endl;
            break;
        case '-':
            cout << "Resultado: " << a - b << endl;
            break;
        case '*':
            cout << "Resultado: " << a * b << endl;
            break;
        case '/':
            if (b == 0) {
                cout << "Error: no se puede dividir entre cero" << endl;
            } else {
                cout << "Resultado: " << a / b << endl;
            }
            break;
        default:
            cout << "Operador no valido" << endl;
    }

    return 0;
}
