#include <iostream>
#include <string>
#include <cctype>
using namespace std;

int main() {
    string frase;
    cout << "Escribe una frase: ";
    getline(cin, frase);

    int n = frase.length();
    int palabras = 0;
    int vocales = 0;
    bool dentroDePalabra = false;

    for (int i = 0; i < n; i++) {
        char c = tolower(frase[i]);

        if (c == ' ') {
            dentroDePalabra = false;
        } else if (!dentroDePalabra) {
            dentroDePalabra = true;
            palabras++;
        }

        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            vocales++;
        }
    }

    string invertida = "";
    for (int i = n - 1; i >= 0; i--) {
        invertida += frase[i];
    }

    cout << "Palabras: " << palabras << endl;
    cout << "Vocales: " << vocales << endl;
    cout << "Invertida: " << invertida << endl;

    return 0;
}
