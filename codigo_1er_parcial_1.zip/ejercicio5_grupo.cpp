#include <iostream>
#include <string>
using namespace std;

class Estudiante {
public:
    string nombre;
    string matricula;
    float promedio;

    Estudiante() {
        nombre = "";
        matricula = "";
        promedio = 0;
    }

    Estudiante(string n, string m, float p) {
        nombre = n;
        matricula = m;
        promedio = p;
    }

    void mostrarInfo() {
        cout << nombre << " (" << matricula << ") - promedio " << promedio << endl;
    }
};

class Grupo {
public:
    Estudiante estudiantes[3];
    int cantidad;

    Grupo() {
        cantidad = 0;
    }

    void agregar(Estudiante e) {
        if (cantidad < 3) {
            estudiantes[cantidad] = e;
            cantidad++;
        }
    }

    float promedioGeneral() {
        float suma = 0;
        for (int i = 0; i < cantidad; i++) {
            suma += estudiantes[i].promedio;
        }
        return suma / cantidad;
    }

    void mostrar() {
        for (int i = 0; i < cantidad; i++) {
            estudiantes[i].mostrarInfo();
        }
    }
};

int main() {
    Grupo grupo;

    grupo.agregar(Estudiante("Ana", "5260010", 92));
    grupo.agregar(Estudiante("Luis", "5260011", 78.5));
    grupo.agregar(Estudiante("Marta", "5260012", 85));

    cout << "Estudiantes del grupo:" << endl;
    grupo.mostrar();
    cout << "Promedio general: " << grupo.promedioGeneral() << endl;

    return 0;
}
